package AST;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class InterfaceNode implements Node {
    public String name;
    public List<MethodHeaderNode> methods = new ArrayList<MethodHeaderNode>();

    @Override
    public String toString() {
        return "interface " + name + "\n" + methods;
    }
}
