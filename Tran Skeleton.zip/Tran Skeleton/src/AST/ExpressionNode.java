package AST;

public interface ExpressionNode  extends Node {
}
